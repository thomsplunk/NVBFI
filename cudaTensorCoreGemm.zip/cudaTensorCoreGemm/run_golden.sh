#!/bin/bash
eval ./cudaTensorCoreGemm > golden_stdout.txt 2> golden_stderr.txt

