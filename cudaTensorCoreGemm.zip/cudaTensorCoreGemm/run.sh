#!/bin/bash
eval ${PRELOAD_FLAG} ${BIN_DIR}/cudaTensorCoreGemm > stdout.txt 2> stderr.txt

